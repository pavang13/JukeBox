package org.example.hellomaven;

public class connectionTest
{
}
